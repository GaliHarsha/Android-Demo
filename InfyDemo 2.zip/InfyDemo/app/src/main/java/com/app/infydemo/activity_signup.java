package com.app.infydemo;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import android.content.Intent;

import com.app.infydemo.R;
import com.app.infydemo.activity_homescreen;

public class activity_signup extends AppCompatActivity {


    private Button Registerbtn;
    EditText etempid, pass1, pass2 ;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);

        Registerbtn =(Button) findViewById(R.id.Signupbtn);
        etempid = (EditText) findViewById(R.id.EmpNo);
        pass1 = (EditText) findViewById(R.id.Pass1);
        pass2 = (EditText) findViewById(R.id.Pass2);

        Registerbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent RegisterIntent = new Intent(activity_signup.this, activity_homescreen.class);
                RegisterIntent.putExtra("Empnumber",etempid.getText().toString());
                if (etempid.getText()!=null && etempid.getText().toString().trim().isEmpty()) {
                    etempid.setError("Enter the EmployeeId");
                }
                else if (pass1.getText()!=null && etempid.getText().toString().trim().isEmpty()){
                    etempid.setError("Enter the Password");
                }
                else if (pass2.getText()!=null && pass2.getText().toString().trim().isEmpty()){
                    pass2.setError("Enter the Email Address");
                }
                else {
                    /*if (etemail.getText().toString().contains("@") && etemail.getText().toString().contains(".com"))*/
                    if(pass1.getText().toString().trim().matches(pass2.getText().toString().trim())){
                        startActivity(RegisterIntent);
                    }
                    else{
                        pass2.setError("Provide valid Confirmation password");
                    }
                }
            }
        });
    }
}
