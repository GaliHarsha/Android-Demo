package com.app.infydemo;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.HashMap;

public class DatabaseHelper extends SQLiteOpenHelper {

    public static final String DATABASE_NAME = "infyapp";
    public static final String TABLE_NAME = "Vendors";
    public static final String Vendor_col0 = "Vendor_Name";
    public static final String Vendor_col1 = "Vendor_location";


    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

        /*db.execSQL("create table "+ TABLE_NAME + "(Vendor_Name TEXT,Vendor_Location TEXT);");
        db.execSQL("INSERT INTO " + TABLE_NAME + ("Murugan Idly Shop",));*/

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
       /* db.execSQL("DROP TABLE IF EXISTS "+ TABLE_NAME);
        onCreate(db);*/

    }

    public void prePoulateData(){
        SQLiteDatabase sqLiteDatabase = this.getWritableDatabase();
        sqLiteDatabase.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
/*        sqLiteDatabase.execSQL("DROP TABLE IF EXISTS " + SUBLOCATION);
        sqLiteDatabase.execSQL("DROP TABLE IF EXISTS " + EMPLOYEE);*/
//
//        String CREATE_LOCATION_TABLE = "CREATE TABLE " + TABLE_NAME + "("
//                + "id " + "INTEGER PRIMARY KEY AUTOINCREMENT," + Vendor_col0 + " TEXT," + Vendor_col1 +" TEXT");
        String CREATE_Vendor_TABLE = "CREATE TABLE " + TABLE_NAME + "("
                + "vendor_name " + "TEXT ," + "vendor_location" + " TEXT)";
//        String CREATE_EMPLOYEE_TABLE = "CREATE TABLE " + EMPLOYEE + "("
//                + "id " + "INTEGER," + "name " + "STRING,"
//                + "contactnumber " + "STRING,"+ "bloodgroup " + "TEXT,"
//                +"dclocation " + " TEXT)";

//        sqLiteDatabase.execSQL(CREATE_LOCATION_TABLE);
        sqLiteDatabase.execSQL(CREATE_Vendor_TABLE);
//        sqLiteDatabase.execSQL(CREATE_EMPLOYEE_TABLE);

        ContentValues vendor = new ContentValues();
//        ContentValues sublocations = new ContentValues();
//        ContentValues empvalues = new ContentValues();


        vendor.put("Murugan Idly shop", "FC1");
        sqLiteDatabase.insert(TABLE_NAME, null, vendor);


        vendor.put("Godavri", "FC3");
        sqLiteDatabase.insert(TABLE_NAME, null, vendor);

        vendor.put("Masala Dhaba", "FC2");
        sqLiteDatabase.insert(TABLE_NAME, null, vendor);

//        sublocations.put("lid", 1);
//        sublocations.put("dclocation", "MahindraCity");
//        sqLiteDatabase.insert(SUBLOCATION, null, sublocations);
//
//        sublocations.put("lid", 1);
//        sublocations.put("dclocation", "Shollinganallur");
//        sqLiteDatabase.insert(SUBLOCATION, null, sublocations);
//
//        sublocations.put("lid", 2);
//        sublocations.put("dclocation", "Narimanpoint");
//        sqLiteDatabase.insert(SUBLOCATION, null, sublocations);
//
//        empvalues.put("id",1);
//        empvalues.put("name","RAM");
//        empvalues.put("contactnumber","9495435433");
//        empvalues.put("bloodgroup","A+");
//        empvalues.put("dclocation","MahindraCity");
//        sqLiteDatabase.insert(EMPLOYEE, null, empvalues);
//
//        empvalues.put("id",2);
//        empvalues.put("name","Ganesh");
//        empvalues.put("contactnumber","9493435733");
//        empvalues.put("bloodgroup","A+");
//        empvalues.put("dclocation","MahindraCity");
//        sqLiteDatabase.insert(EMPLOYEE, null, empvalues);
//
//        empvalues.put("id",3);
//        empvalues.put("name","Hari");
//        empvalues.put("contactnumber","8775844435");
//        empvalues.put("bloodgroup","B+");
//        empvalues.put("dclocation","Narimanpoint");
//        sqLiteDatabase.insert(EMPLOYEE, null, empvalues);
//
//        empvalues.put("id",4);
//        empvalues.put("name","Haran");
//        empvalues.put("contactnumber","8685845485");
//        empvalues.put("bloodgroup","AB-");
//        empvalues.put("dclocation","Shollinganallur");
//        sqLiteDatabase.insert(EMPLOYEE, null, empvalues);
//
//        empvalues.put("id",5);
//        empvalues.put("name","Shiv");
//        empvalues.put("contactnumber","9485845485");
//        empvalues.put("bloodgroup","B-");
//        empvalues.put("dclocation","Narimanpoint");
//        sqLiteDatabase.insert(EMPLOYEE, null, empvalues);
//        sqLiteDatabase.close();

        System.out.println("DB success");
    }

    public ArrayList<HashMap<String,String>> getVendorsDetails(String Vendors){

        String vendorQuery = "SELECT vendor_name,vendor_location FROM" + Vendors;
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor3 = db.rawQuery(vendorQuery, null);
        ArrayList<HashMap<String, String>> vendorlist = new ArrayList<>();

        if (cursor3.moveToFirst()) {

            do {

                HashMap<String,String> vendor = new HashMap<>();
                vendor.put("vendor_name",cursor3.getString(cursor3.getColumnIndex("vendor_name")));
                vendor.put("vendor_location",cursor3.getString(cursor3.getColumnIndex("vendor_location")));
                vendorlist.add(vendor);
            } while (cursor3.moveToNext());

        }
        cursor3.close();
        db.close();
        return vendorlist;

    }

    public SQLiteDatabase getDb() {
        return this.getReadableDatabase();
    }
}
