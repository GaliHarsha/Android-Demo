package com.app.infydemo;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.app.infydemo.activity_signup;
import com.app.infydemo.activity_login;
import com.app.infydemo.R;

public class MainActivity extends AppCompatActivity {

    private Button Login, Signup;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Login = (Button) findViewById(R.id.MainLoginbtn);
        Signup = (Button) findViewById(R.id.Signupbtn);

        Login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent Login = new Intent(MainActivity.this,activity_login.class);
                startActivity(Login);
            }
        });
        Signup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent Signup = new Intent(MainActivity.this,activity_signup.class);
                startActivity(Signup);
            }
        });
    }
}
