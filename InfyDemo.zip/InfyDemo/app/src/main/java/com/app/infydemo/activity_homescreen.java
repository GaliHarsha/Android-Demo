package com.app.infydemo;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.app.infydemo.activity_offers;
import com.app.infydemo.activity_statement;
import com.app.infydemo.activity_signup;
import com.app.infydemo.R;

public class activity_homescreen extends AppCompatActivity {

    private Button offersbtn, statementbtn, rechargebtn,vendorbtn, paybtn;
    TextView Empdisp;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_homescreen);

        offersbtn = (Button) findViewById(R.id.offersbtn);
        statementbtn = (Button) findViewById(R.id.statementbtn);
        rechargebtn = (Button) findViewById(R.id.Rechargebtn);
        vendorbtn = (Button) findViewById(R.id.vendorsbtn);
        paybtn = (Button) findViewById(R.id.paybtn);

        Empdisp = (TextView) findViewById(R.id.Empdisp);
        Empdisp.setText(getIntent().getExtras().getString("Empnumber"));

        offersbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent offers = new Intent(activity_homescreen.this,activity_offers.class);
                startActivity(offers);
            }
        });

        statementbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent statement = new Intent(activity_homescreen.this,activity_statement.class);
                startActivity(statement);
            }
        });

        rechargebtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent recharge = new Intent(activity_homescreen.this,activity_recharge.class);
                startActivity(recharge);
            }
        });

        vendorbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent vendor = new Intent(activity_homescreen.this,activity_vendors.class);
                startActivity(vendor);
            }
        });

        paybtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent pay = new Intent(activity_homescreen.this,activity_pay.class);
                startActivity(pay);
            }
        });


    }
}
